from proses_program import file

#membuat objek dari class fileprocessor
file_processor = file()

#mengetes fungsi membaca file
file_processor.baca_file('contoh_file.txt')

#mengetes fungsi menulis file
file_processor.tulis_file('file_neyla.txt', 'Neyla Ayudya', 'w')
file_processor.tulis_file('file_neyla.txt', '\nSMKN 9 Malang', 'a')